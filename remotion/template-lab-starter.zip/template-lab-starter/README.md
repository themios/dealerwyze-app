# Vehicle Video Template Lab Starter

This starter project gives you:
- a prop-driven Remotion template lab
- 3 initial presets
- sample vehicle data
- a comparison-oriented composition
- an HTML wireframe for the internal template lab UI

## Included presets
1. Budget Daily Driver
2. Family SUV
3. Fast Reel

## Suggested next steps
1. Run `npm install`
2. Start Remotion Studio with `npm run studio`
3. Edit the preset JSON files in `src/presets`
4. Replace sample vehicle images/data with real dealership data
5. Expand the scene logic and voice integrations
6. Use the HTML wireframe to align the internal UI before coding the full web interface

## Commands

```bash
npm install
npm run studio
npm run render:budget
npm run render:family
npm run render:fast
```

## Notes
- The code is structured for rapid iteration, not full production hardening.
- The voice layer is represented in the config schema but not fully implemented in this starter.
- Presets are JSON-driven so you can later load them from a DB in your SaaS.
