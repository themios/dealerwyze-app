import React from 'react';
import {AbsoluteFill, Img, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {VideoTemplateProps} from '../lib/types';
import {TextBlock} from '../components/TextBlock';
import {LogoBadge} from '../components/LogoBadge';
import {CtaBar} from '../components/CtaBar';

const gradientOverlay = (primary: string) =>
  `linear-gradient(180deg, rgba(0,0,0,0.10) 0%, rgba(0,0,0,0.15) 35%, rgba(0,0,0,0.58) 100%), linear-gradient(135deg, ${primary}20 0%, transparent 50%)`;

export const VehicleTemplate: React.FC<VideoTemplateProps> = (props) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();

  const images = props.images.length ? props.images : ['https://images.unsplash.com/photo-1494976388531-d1058494cdd8?auto=format&fit=crop&w=1200&q=80'];
  const framesPerImage = Math.max(1, Math.floor(durationInFrames / images.length));
  const index = Math.min(images.length - 1, Math.floor(frame / framesPerImage));
  const activeImage = images[index];
  const localFrame = frame % framesPerImage;

  const entry = spring({
    frame: localFrame,
    fps,
    config: {damping: 16, stiffness: 90},
  });

  const zoom = interpolate(entry, [0, 1], [1.08, 1], {extrapolateRight: 'clamp'});
  const translateY = interpolate(entry, [0, 1], [24, 0], {extrapolateRight: 'clamp'});
  const opacity = interpolate(entry, [0, 0.25, 1], [0, 1, 1]);

  return (
    <AbsoluteFill
      style={{
        background: '#0b1220',
        fontFamily: props.branding.fontFamily,
      }}
    >
      <Img
        src={activeImage}
        style={{
          width: '100%',
          height: '100%',
          objectFit: 'cover',
          transform: `scale(${zoom}) translateY(${translateY}px)`,
          opacity,
        }}
      />
      <AbsoluteFill style={{background: gradientOverlay(props.branding.primaryColor)}} />
      <AbsoluteFill
        style={{
          background: 'radial-gradient(circle at 50% 110%, rgba(255,255,255,0.08), transparent 45%)',
        }}
      />

      <LogoBadge
        text={props.branding.logoText}
        color="#ffffff"
        background="rgba(15,23,42,0.55)"
        position={props.layout.logoPosition}
      />

      <TextBlock
        hook={props.messaging.hook}
        subHook={props.messaging.subHook}
        body={props.messaging.body}
        color="#ffffff"
        fontFamily={props.branding.fontFamily}
        scale={props.typography.fontSizeScale}
        position={props.layout.headlinePosition}
      />

      <div
        style={{
          position: 'absolute',
          left: 48,
          top: 1420,
          display: 'grid',
          gap: 14,
          color: '#fff',
        }}
      >
        <div style={{fontSize: 52, fontWeight: 900}}>
          ${props.vehicle.price.toLocaleString()}
        </div>
        <div style={{fontSize: 28, fontWeight: 600, opacity: 0.96}}>
          {props.vehicle.year} {props.vehicle.make} {props.vehicle.model} {props.vehicle.trim}
        </div>
        <div style={{fontSize: 22, fontWeight: 500, opacity: 0.88}}>
          {props.vehicle.mileage.toLocaleString()} miles
        </div>
      </div>

      <div
        style={{
          position: 'absolute',
          left: 48,
          right: 48,
          top: 1560,
          display: 'flex',
          flexWrap: 'wrap',
          gap: 12,
        }}
      >
        {props.vehicle.features.slice(0, 4).map((feature) => (
          <div
            key={feature}
            style={{
              padding: '12px 18px',
              borderRadius: 999,
              background: 'rgba(255,255,255,0.14)',
              color: '#fff',
              fontSize: 20,
              fontWeight: 600,
              backdropFilter: 'blur(12px)',
            }}
          >
            {feature}
          </div>
        ))}
      </div>

      <CtaBar
        text={props.cta.text}
        styleType={props.cta.style}
        primary={props.branding.primaryColor}
        accent={props.branding.accentColor}
      />
    </AbsoluteFill>
  );
};
