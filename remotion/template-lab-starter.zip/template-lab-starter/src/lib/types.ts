export type TemplateFormat = 'reel' | 'slideshow' | 'split' | 'cinematic';

export type VideoTemplateProps = {
  presetId: string;
  vehicle: {
    year: number;
    make: string;
    model: string;
    trim: string;
    price: number;
    mileage: number;
    features: string[];
  };
  images: string[];
  branding: {
    dealerName: string;
    logoText: string;
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    fontFamily: string;
  };
  layout: {
    format: TemplateFormat;
    aspectRatio: '9:16' | '1:1' | '16:9';
    imageLayout: 'single' | 'grid' | 'split';
    headlinePosition: 'top' | 'center' | 'bottom';
    logoPosition: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  };
  timing: {
    durationSec: number;
    imageDurationMs: number;
    transitionSpeed: number;
  };
  typography: {
    fontSizeScale: number;
    textDensity: 'low' | 'medium' | 'high';
  };
  animation: {
    transitionStyle: 'cut' | 'fade' | 'zoom' | 'slide';
  };
  narration: {
    enabled: boolean;
    voiceId: string;
    speechRate: number;
    scriptSource: 'rules' | 'llm' | 'custom';
  };
  subtitles: {
    enabled: boolean;
    style: 'minimal' | 'bold';
  };
  cta: {
    text: string;
    style: 'pill' | 'banner' | 'minimal';
  };
  messaging: {
    hook: string;
    subHook: string;
    body: string;
  };
};
