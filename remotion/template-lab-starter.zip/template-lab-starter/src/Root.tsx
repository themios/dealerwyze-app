import React from 'react';
import {Composition} from 'remotion';
import {VehicleTemplate} from './templates/VehicleTemplate';
import budgetPreset from './presets/budget-daily-driver.json';
import familyPreset from './presets/family-suv.json';
import fastPreset from './presets/fast-reel.json';

const fps = 30;

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <Composition
        id="BudgetDailyDriver"
        component={VehicleTemplate}
        durationInFrames={budgetPreset.timing.durationSec * fps}
        fps={fps}
        width={1080}
        height={1920}
        defaultProps={budgetPreset}
      />
      <Composition
        id="FamilySUV"
        component={VehicleTemplate}
        durationInFrames={familyPreset.timing.durationSec * fps}
        fps={fps}
        width={1080}
        height={1920}
        defaultProps={familyPreset}
      />
      <Composition
        id="FastReel"
        component={VehicleTemplate}
        durationInFrames={fastPreset.timing.durationSec * fps}
        fps={fps}
        width={1080}
        height={1920}
        defaultProps={fastPreset}
      />
    </>
  );
};
