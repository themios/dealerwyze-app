import React from 'react';

export const CtaBar: React.FC<{
  text: string;
  styleType: 'pill' | 'banner' | 'minimal';
  primary: string;
  accent: string;
}> = ({text, styleType, primary, accent}) => {
  const common: React.CSSProperties = {
    position: 'absolute',
    left: 48,
    right: 48,
    bottom: 56,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    fontWeight: 800,
    letterSpacing: '0.02em',
  };

  if (styleType === 'minimal') {
    return (
      <div style={{...common, color: '#fff', fontSize: 30}}>
        {text}
      </div>
    );
  }

  if (styleType === 'banner') {
    return (
      <div
        style={{
          ...common,
          background: `linear-gradient(90deg, ${primary}, ${accent})`,
          color: '#fff',
          borderRadius: 18,
          height: 92,
          fontSize: 32,
          boxShadow: '0 12px 28px rgba(0,0,0,0.25)',
        }}
      >
        {text}
      </div>
    );
  }

  return (
    <div
      style={{
        ...common,
        display: 'inline-flex',
        margin: '0 auto',
      }}
    >
      <div
        style={{
          background: '#ffffff',
          color: '#0f172a',
          borderRadius: 999,
          padding: '20px 34px',
          fontSize: 30,
          boxShadow: '0 10px 26px rgba(0,0,0,0.24)',
        }}
      >
        {text}
      </div>
    </div>
  );
};
