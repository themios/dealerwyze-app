import React from 'react';

export const LogoBadge: React.FC<{
  text: string;
  color: string;
  background: string;
  position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
}> = ({text, color, background, position}) => {
  const pos: Record<string, React.CSSProperties> = {
    'top-left': {top: 42, left: 42},
    'top-right': {top: 42, right: 42},
    'bottom-left': {bottom: 42, left: 42},
    'bottom-right': {bottom: 42, right: 42},
  };

  return (
    <div
      style={{
        position: 'absolute',
        ...pos[position],
        padding: '16px 22px',
        borderRadius: 999,
        background,
        color,
        fontWeight: 800,
        fontSize: 24,
        letterSpacing: '0.08em',
        backdropFilter: 'blur(10px)',
        boxShadow: '0 8px 24px rgba(0,0,0,0.22)',
      }}
    >
      {text}
    </div>
  );
};
