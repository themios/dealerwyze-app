import React from 'react';

export const TextBlock: React.FC<{
  hook: string;
  subHook: string;
  body: string;
  color: string;
  fontFamily: string;
  scale: number;
  position: 'top' | 'center' | 'bottom';
}> = ({hook, subHook, body, color, fontFamily, scale, position}) => {
  const justifyContent =
    position === 'top' ? 'flex-start' : position === 'center' ? 'center' : 'flex-end';

  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        display: 'flex',
        flexDirection: 'column',
        justifyContent,
        padding: 56,
        gap: 16,
      }}
    >
      <div
        style={{
          maxWidth: 840,
          color,
          fontFamily,
          fontWeight: 800,
          fontSize: 72 * scale,
          lineHeight: 1.02,
          textTransform: 'uppercase',
          letterSpacing: '-0.03em',
          textShadow: '0 10px 28px rgba(0,0,0,0.45)',
        }}
      >
        {hook}
      </div>
      <div
        style={{
          maxWidth: 860,
          color,
          fontFamily,
          fontWeight: 600,
          fontSize: 34 * scale,
          lineHeight: 1.12,
          textShadow: '0 8px 18px rgba(0,0,0,0.35)',
        }}
      >
        {subHook}
      </div>
      <div
        style={{
          maxWidth: 760,
          color: 'rgba(255,255,255,0.94)',
          fontFamily,
          fontWeight: 500,
          fontSize: 24 * scale,
          lineHeight: 1.35,
          textShadow: '0 6px 16px rgba(0,0,0,0.35)',
        }}
      >
        {body}
      </div>
    </div>
  );
};
